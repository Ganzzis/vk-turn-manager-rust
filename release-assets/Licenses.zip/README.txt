MIT notice for VK TURN Manager, Swift dependency license and notice files from the app build,
and the GPLv3 license and corresponding source reference for the separate upstream SRTP executable.
The matching SRTP source archive is a separate attachment, srtp-build478-source.tar.gz.
Rust includes notices from dependency archives checked against Cargo.lock.
The lockfile also records non-Linux dependencies, including r-efi (UEFI only), which are not shipped.
